@extends('layout.index')

@section('content')
<h1>Pàgina de publicacions</h1>
@endsection